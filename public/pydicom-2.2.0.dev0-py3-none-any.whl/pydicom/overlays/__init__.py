from pydicom.overlays.numpy_handler import get_overlay_array
